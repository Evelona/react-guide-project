import { CSSTransition, TransitionGroup } from 'react-transition-group'
import { useContext, useEffect, useState } from 'react'

import { FloorsContext } from 'contexts/floors-context'
import { MASK_COUNT } from 'config'
import Mask from './components/Mask'

const changeMask = (index) => {
	if (index === MASK_COUNT - 1) return 0

	return index += 1
}

export default () => {
	const [maskIndex, setMaskIndex] = useState(0)

	const { roomExhibit } = useContext(FloorsContext)

	useEffect(() => {
		setMaskIndex(changeMask(maskIndex))
	}, [roomExhibit])

	return pug`
		TransitionGroup
			if maskIndex === 0
				CSSTransition(key=0 timeout=300)
					Mask(index=0)
			if maskIndex === 1
				CSSTransition(key=1 timeout=300)
					Mask(index=1)
			if maskIndex === 2
				CSSTransition(key=2 timeout=300)
					Mask(index=2)
			if maskIndex === 3
				CSSTransition(key=3 timeout=300)
					Mask(index=3)
			if maskIndex === 4
				CSSTransition(key=4 timeout=300)
					Mask(index=4)
	`
}
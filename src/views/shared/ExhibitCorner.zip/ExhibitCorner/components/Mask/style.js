import styled, { keyframes } from 'styled-components'

const crossingVertical = keyframes`
    0% { background-position: 0 0; }
    100% { background-position: 100% 100%; }
`

const crossingGorizontal = keyframes`
    0% { background-position: 100px 0; }
    100% { background-position: -90px 0; }
`

export const Corner = styled.div`
    background: ${({ path }) => `url(./exhibits/${path}) no-repeat`};
    background-position: 0 0;
    background-size: cover;
    position: absolute;
    bottom: 0;
    right: 0;
    width: 2225px;
    height: 1745px;

    animation: ${({ direction }) => direction === 'vertical' ? crossingVertical : crossingGorizontal} 3s linear infinite;
    // animation: ${crossingVertical} 3s linear infinite;
`

export const Wrapper = styled.div`
    mask: ${({ mask }) => `url(./masks/v${mask}.webp) center no-repeat`};
    // mask: url(./masks/v0.webp) center no-repeat;
    position: absolute;
    top: 0;
    width: 3840px;
    height: 2160px;
    overflow: hidden;

    &.enter {
		opacity: 0;
	}
	&.enter-active { 
		opacity: 1;
        transition: opacity 300ms;	
    }
	&.exit { 
		opacity: 1; 
	}
	&.exit-active { 
		opacity: 0;
		transition: opacity 300ms; 
	}
`

export const ExhibitTitle = styled.p`
    position: absolute;
    top: 1400px;
    right: 300px;
    text-align: right;
    
    // центрирование по середине маски
    max-width: 38vw;
    width: 100%;
    text-align: right;
    
    color: #fff;
    font-size: 144px;
`
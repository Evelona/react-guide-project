import { Corner, ExhibitTitle, Wrapper } from './style'

import { FloorsContext } from 'contexts/floors-context'
import { Multilang } from 'langs'
import { useContext } from 'react'

const Mask = ({ index }) => {
	const { roomExhibit } = useContext(FloorsContext)
	const { imgPath, description, photoId, direction } = roomExhibit

	return pug`
		Wrapper(mask=index)
			Corner(key=photoId path=imgPath direction=direction)
				ExhibitTitle 
					Multilang(...description)
`
}

export default Mask